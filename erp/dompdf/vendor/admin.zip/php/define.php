<?php

$GLOBALS = array(
    "host" => "localhost",
    "url" => "http://lebailmobilite.com/",
    "username" => "mvmtnqxp_mobilite",
    "password" => "Mobilite@123"
);

$temppath = "/home/mvmtnqxp/public_html/temp/";
$photopath =  "/home/mvmtnqxp/public_html/slider_images/";
$ppicpath =  "/home/mvmtnqxp/public_html/profilepics/";